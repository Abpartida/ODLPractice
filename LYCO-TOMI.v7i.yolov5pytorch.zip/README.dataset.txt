# LYCO:TOMI > 2026-01-20 3:08pm
https://universe.roboflow.com/pest-identification-njqyz/lyco-tomi-42im4

Provided by a Roboflow user
License: CC BY 4.0

